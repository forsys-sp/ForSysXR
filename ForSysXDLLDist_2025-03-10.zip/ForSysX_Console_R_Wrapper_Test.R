#' ForSysX dll console wrapper
#'
#' @param exe_path string path to the ForSysXConsole.exe file
#' @param xml_path string path to the ForSysX xml settings file

# Define the path to your C++ DLL file
exe_path <- "C:/path/ForSysXConsole.exe"

# Define the path to the ForSysX xml project settings file.
xml_path <- "C:/path/my_project_settings.xml"

# Run ForSysX using the wrapper function
source("ForSysX_Console_R_Wrapper.R")
run_forsysx_console(exe_path, xml_path)
