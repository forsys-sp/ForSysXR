#' ForSysX dll wrapper
#'
#' @param dll_path string path to the ForSysX dll file
#' @param xml_path string path to the ForSysX xml settings file

# ForSysX wrapper function
run_forsysx <- function(dll_path, xml_path) {
  # Get current working directory
  current_dir <- getwd()

  # Load the DLL using dyn.load:
  dll <- dyn.load(dll_path)
  
  # Point the dll to the file path
  script_path <- dirname(rstudioapi::getSourceEditorContext()$path)
  text_file_path <- file.path(script_path, "ProjectXMLPath.txt")
  write(xml_path, text_file_path, append=FALSE)
  
  # Run ForSysX using the created text file
  .C("run_by_file")
  
  # Unload the DLL
  dyn.unload(dll_path)
  
  # Restore working directory
  setwd(current_dir)
}