#' ForSysX dll console wrapper
#'
#' @param exe_path string path to the ForSysXConsole.exe file
#' @param xml_path string path to the ForSysX xml settings file

# ForSysX console wrapper function
run_forsysx_console <- function(exe_path, xml_path) {
  
  # Call a console application without showing the console window
  command <- paste(exe_path, xml_path)
  #shell(command, invisible = TRUE)
  system2("cmd.exe", c("/c", command), invisible = TRUE, wait = TRUE)
}