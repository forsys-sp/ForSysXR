#.....................................................................

#' Test ForSysX dll wrapper
#'
#' @param dll_path string path to the ForSysX dll file 
#' @param xml_path string path to the ForSysX xml settings file

# Define the path to your C++ DLL file
dll_path <- "C:/path/ForSysXAPI.dll"

# Define the path to the ForSysX xml project settings file.
xml_path <- "C:/path/my_project_settings.xml"

# Run ForSysX using the wrapper function (note that we assume the script is in the current directory)
source("ForSysX_R_Wrapper.R")
run_forsysx(dll_path, xml_path)
